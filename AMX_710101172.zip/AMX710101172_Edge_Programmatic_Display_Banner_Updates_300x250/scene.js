function newCanvas(config) {
    const _canvas = document.createElement('canvas');
    _canvas.width = (config && config.width) ? config.width : banner.width * 2;
    _canvas.height = (config && config.height) ? config.height : banner.height * 2;
    const _ctx = _canvas.getContext('2d');
    const _sprite = newSprite(_canvas, (config && config.ctx) ? config.ctx : ctx, { width: _canvas.width, height: _canvas.height })
    _sprite.x = (config && config.x) ? config.x : canvas.width * 0.5
    _sprite.y = (config && config.y) ? config.y : canvas.height * 0.5
    _sprite.scaleX = (config && config.scaleX) ? config.scaleX : null
    _sprite.scaleY = (config && config.scaleY) ? config.scaleY : null
    _sprite.scale = (config && config.scale) ? config.scale : 1
    return {
        canvas: _canvas,
        ctx: _ctx,
        sprite: _sprite
    }
}

// MASTER CANVAS
const canvas = document.querySelector(".scene canvas");
canvas.width = document.querySelector(".banner").offsetWidth * 2
canvas.height = document.querySelector(".banner").offsetHeight * 2
const ctx = canvas.getContext('2d');

// const SCENE = new gsap.timeline({onUpdate: () => { banner.update ? banner.update() : null }})
const SCENE = new gsap.timeline()

function initScene (config) {
    // scale 
    canvas.width = banner.width * 2;
    canvas.height = banner.height * 2;

    const scene = newCanvas()
    banner.sceneSprite = newSprite(scene.canvas, ctx, {width: canvas.width, height: canvas.height})
    banner.sceneSprite.x = canvas.width * .5
    banner.sceneSprite.y = canvas.height * .5


    /** ****************
     * 
     * SPRITES LIST
     * 
     **************** */
    
    // FOREGROUND CONTEXT
    banner.frame1 = newSprite('.frame-01', scene.ctx)
    banner.frame2 = newSprite('.frame-01', scene.ctx)
    banner.frame3 = newSprite('.frame-01', scene.ctx)
    banner.frame4 = newSprite('.frame-01', scene.ctx)


    /** ****************
     * 
     * SET LAYER ORDER
     * 
     **************** */
    banner.sprites = [  
        // layer 0
        banner.frame1,
        banner.frame2,
        banner.frame3,
        banner.frame4,
        scene.sprite
    ]
    banner.backgrounds = [
        banner.frame1,
        banner.frame2,
        banner.frame3,
        banner.frame4
    ]
    banner.sprites.map(sprite => {
        centerSprite(sprite, canvas)
    })

    

    const layers = [
        scene    
    ]

    
    /** ****************
     * 
     * CANVAS UPDATE FUNCTION
     * 
     **************** **/ 
    banner.update = () => {
        layers.map(layer => {
            layer.ctx.clearRect(0,0,layer.canvas.width,layer.canvas.height)
        })
        ctx.clearRect(0,0,canvas.width,canvas.height)
        
        scene.ctx.fillStyle = "red"
        scene.ctx.fillRect(0,0,canvas.width,canvas.height)

        banner.sprites.map(sprite => {
            drawSprite(sprite)
        })        

        
    }
    banner.update()

    /** ****************
     * 
     * CANVAS SCENE TIMELINE
     * 
     **************** **/ 
    SCENE
        .from(banner.sprites, {duration: 10, ease: Sine.easeOut}, 0)
}