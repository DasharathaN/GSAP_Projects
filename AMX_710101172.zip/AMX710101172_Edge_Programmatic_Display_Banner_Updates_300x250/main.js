var banner = {
    data: {}
}
var TIMELINE;
//////////////////////////////////////////////////////////////////////////////////

// INIT BANNER ----------------------------------
function init() {
    setBannerSize();

    gsap.set(".common, .scene", { display: "block" });
    gsap.set(".htmlMem", { skewX: 0.01, transformOrigin: "50% 50%" });

    addListeners(onMouseOver, onMouseLeave);
    startBanner();
}

function onMouseOver() {
    document.querySelector(".cta").classList.add("over")
}
function onMouseLeave() {
    document.querySelector(".cta").classList.remove("over")
}

function startBanner() {

    gsap.set(".banner", { display: "block" });
    gsap.from(".htmlMem", { duration: 0.25, opacity: 0, ease: Power3.easeIn });

    // duplicate logo SVG
    initScene({scale: 1.1})

    const FRAME1 = new gsap.timeline()
        .from(".background.blue, .frame1", {duration: 1, x: "-=100%", ease: Power3.easeInOut})
        .from(".frame1 .copy", {x: -20, opacity: 0, ease: Power3.easeOut}, "-=0.3")
        .from(".frame1 .shimmer", {duration: 2, x: "-270%", ease: Power3.easeInOut}, 0.5)
        .from(banner.backgrounds[0].offset, {duration: 4, ease:Quad.easeInOut}, 0)
        

        
    const FRAME2 = new gsap.timeline()
        .to(".frame1", {x: -20, opacity: 0, ease: Power3.easeIn})
        .from(".frame2, .frame2 .copy", {x: -20, opacity: 0, stagger: 0.1, ease: Power3.easeOut})
        
        .from(banner.backgrounds[1], {duration: 0.5, alpha: 0, ease:Quad.easeInOut}, 0)
        .from(banner.backgrounds[1].offset, {duration: 4, ease:Quad.easeInOut}, 0)
    
    const FRAME3 = new gsap.timeline()
        .to(".frame2", {x: -20, opacity: 0, ease: Power3.easeIn})
        .from(".frame3, .frame3 .copy", {x: -20, opacity: 0, stagger: 0.1, ease: Power3.easeOut})

        .from(banner.backgrounds[2], {duration: 0.5, alpha: 0, ease:Quad.easeInOut}, 0)
        .from(banner.backgrounds[2].offset, {duration: 4.5, ease:Quad.easeInOut}, 0)
    
    const FRAME4 = new gsap.timeline()
        .to(".frame3", {x: -20, opacity: 0, ease: Power3.easeIn})
        .from(".frame4, .frame4 .copy", {x: -20, opacity: 0, stagger: 0.1, ease: Power3.easeOut})

        .from(banner.backgrounds[3], {duration: 0.5, alpha: 0, ease:Quad.easeInOut}, 0)
        .from(banner.backgrounds[3].offset, {duration: 4.5, ease:Quad.easeInOut}, 0)

    const FRAME5 = new gsap.timeline()
        .to(".background.blue, .frame4", {duration: 1, x: "-=100%", ease: Power3.easeInOut})
        .from(".frame5", {duration: .6, y: "-=100%", ease: Power3.easeInOut}, "-=0.8")
        .from(".frame5 .heading, .frame5 .sub-heading, .frame5 .cta, .frame5 .terms", {x: -20, opacity: 0, stagger: 0.1, ease: Power3.easeOut}, "-=0.3")
        .from(".frame5 .card", {y: 20, opacity: 0, stagger: 0.1, ease: Power3.easeOut}, "-=0.6")
        .from(".frame5 .shimmer", {duration: 1.5, x: "-270%", ease: Power3.easeInOut}, "-=0.3")
    
    const LOOPCHECK = new gsap.timeline({ onComplete: loop })
    const REPLAY = new gsap.timeline()
        .to(".fade", { duration: 0.3, opacity: 1 })
        


    // MASTER TIMELINE
    TIMELINE = new gsap.timeline({ repeat: 2, onUpdate: () => { banner.update ? banner.update() : null }})
        .add(FRAME1)
        .add(FRAME2, "-=1.0")
        .add(FRAME3, "-=1.0")
        .add(FRAME4, "-=1.0")
        .add(FRAME5, "-=1.5")

        .add(LOOPCHECK, "+=3")
        .addLabel("replay")
        .add(REPLAY)
        .add(SCENE, 0)
        .to(".fade", { duration: 0.3, opacity: 0 }, 0)
        // .pause(3)
}


function loop() {
TIMELINE.pause();

    // if (!banner.looped) {
    //     banner.looped = true;
    //     TIMELINE.play("replay")
    // } else {
    //     TIMELINE.pause();
    // }
}


// window.addEventListener("load", init);
const loadImages = () => {
    const _scene = document.querySelector(".scene")
        const images = [
            "frame-02",
            "frame-03",
            "frame-04",
        ]
        images.map(src => {
            const img = document.createElement("img")
            img.src = src + ".jpg"
            img.className = "absolute hidden " + src
            img.addEventListener("load", () => {
                banner[src.split("-0").join("")].img.src = img;
            })
            _scene.appendChild(img)
        })
}

window.onload = function () {
    init()

    if (Enabler.isInitialized()) {
        loadImages()
    } else {
        Enabler.addEventListener(studio.events.StudioEvent.INIT, loadImages);
    }
};